-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 10 Jun 2013 pada 15.03
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `projek`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `ID_admin` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_admin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`ID_admin`, `username`, `password`) VALUES
(1, 'admin', 'lingga');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `ID_barang` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` int(50) NOT NULL,
  `waktu` datetime NOT NULL,
  `status` int(1) NOT NULL,
  `keterangan` longtext NOT NULL,
  PRIMARY KEY (`ID_barang`),
  KEY `jenis` (`jenis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`ID_barang`, `jenis`, `waktu`, `status`, `keterangan`) VALUES
(1, 1, '2013-05-17 00:00:00', 1, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna aliqua nostrud exercitation. Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorreprehenderit in voluptate velit esse cillum doloreAt vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repella'),
(2, 3, '2013-05-02 00:00:00', 0, 'Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorreprehenderit in voluptate velit esse cillum dolore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna aliqua nostrud exercitation. Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorreprehenderit in voluptate velit esse cillum dolore.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repella'),
(3, 3, '2013-05-09 00:00:00', 0, '<p>Duis aute irure dolorreprehenderit in voluptate velit esse cillum dolore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna aliqua nostrud exercitation. Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorreprehenderit in voluptate velit esse cillum dolore.Adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repella</p>\r\n'),
(4, 2, '2013-05-03 00:00:00', 1, 'adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna. aute irure dolorreprehenderit in voluptate velit esse cillum dolore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna aliqua nostrud exercitation. Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorreprehenderit in voluptate velit esse cillum dolore.Adipisicing elit, sed do eiusmod tempor inciddunt ut labore et dolore magna.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repella'),
(6, 1, '2013-06-20 00:00:00', 2, '<p>0</p>\r\n'),
(7, 3, '2013-06-11 00:00:00', 0, 'keterangan'),
(8, 3, '2013-06-04 11:28:10', 0, '<p><strong>berwarna pink</strong></p>\r\n'),
(9, 3, '2013-06-04 11:28:10', 0, '<p><strong>berwarna pinkvvvvvvv</strong></p>\r\n'),
(10, 1, '2013-06-27 00:00:00', 1, '<p>keterangan</p>\r\n'),
(11, 1, '2013-06-27 00:00:00', 1, '<p>keteranganjjjjj</p>\r\n'),
(12, 1, '0000-00-00 00:00:00', 0, '<p>keterangan</p>\r\n'),
(13, 1, '0000-00-00 00:00:00', 0, '<p>keterangan</p>\r\n'),
(14, 1, '0000-00-00 00:00:00', 0, '<p>keterangan</p>\r\n'),
(15, 1, '0000-00-00 00:00:00', 0, '<p>keterangan</p>\r\n'),
(16, 3, '0000-00-00 00:00:00', 1, 'hhhhhh'),
(17, 1, '2013-06-13 13:24:30', 0, '<p>keterangan</p>\r\n'),
(18, 3, '2013-03-27 00:48:50', 2, '<p>gggggg</p>\r\n'),
(19, 1, '2013-06-26 00:00:00', 0, '<p>keterangan</p>\r\n'),
(20, 3, '2013-08-21 14:14:30', 2, '<p>ooooooooooooooooooooooooooooooooo</p>\r\n'),
(21, 1, '2013-06-27 00:00:00', 1, '<p>keteranganbbbbbbbbbbbbbbbbbbbbbbbbbb</p>\r\n\r\n<p>bbbbbbbbbbbbbbbbbbbbbbbbbbbb</p>\r\n\r\n<p>bbbbbbbbbbbbbbbbbbbbbbbbbbbbb</p>\r\n'),
(22, 3, '2013-06-06 16:42:00', 0, '<p>keteranganssssssssssssss</p>\r\n'),
(23, 2, '2013-06-20 00:00:00', 0, '<p>keterangancccccccccccccccccccccccccsssssss<strong>sssssssssssssssssss</strong></p>\r\n'),
(24, 3, '2013-06-27 00:00:00', 1, '<p>keterangankmhgcmfhgfbdfgfgfgfgfgfgfgghghghjhjhjhjh</p>\r\n'),
(25, 2, '2013-06-20 14:17:00', 1, '<p>keteranganbbbbbbbbbbbbbb</p>\r\n'),
(26, 1, '2013-06-06 16:19:20', 0, '<p>keterangan</p>\r\n'),
(27, 2, '2013-06-07 09:29:10', 1, '<p>keterangan</p>\r\n'),
(28, 1, '0000-00-00 00:00:00', 0, ''),
(29, 1, '0000-00-00 00:00:00', 0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail`
--

CREATE TABLE IF NOT EXISTS `detail` (
  `ID_detail` int(11) NOT NULL AUTO_INCREMENT,
  `no_subjek` int(11) NOT NULL,
  `no_barang` int(11) NOT NULL,
  `no_lokasi` int(11) NOT NULL,
  PRIMARY KEY (`ID_detail`),
  KEY `ID_pengilang` (`no_subjek`),
  KEY `ID_brg_ilang` (`no_barang`),
  KEY `ID_lokasi` (`no_lokasi`),
  KEY `ID_subjek` (`no_subjek`),
  KEY `ID_barang` (`no_barang`),
  KEY `ID_lokasi_2` (`no_lokasi`),
  KEY `no_subjek` (`no_subjek`),
  KEY `no_barang` (`no_barang`),
  KEY `no_lokasi` (`no_lokasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data untuk tabel `detail`
--

INSERT INTO `detail` (`ID_detail`, `no_subjek`, `no_barang`, `no_lokasi`) VALUES
(1, 1, 1, 4),
(2, 2, 2, 2),
(3, 1, 3, 3),
(4, 2, 4, 5),
(5, 3, 3, 1),
(6, 1, 4, 6),
(7, 17, 18, 4),
(8, 5, 6, 5),
(9, 6, 7, 4),
(10, 18, 19, 1),
(11, 19, 20, 1),
(12, 20, 21, 3),
(13, 27, 22, 1),
(14, 28, 23, 3),
(15, 29, 24, 1),
(16, 30, 25, 1),
(17, 31, 26, 1),
(18, 32, 27, 3),
(19, 33, 28, 1),
(20, 34, 29, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `finish`
--

CREATE TABLE IF NOT EXISTS `finish` (
  `ID_finish` int(11) NOT NULL AUTO_INCREMENT,
  `pelapor` int(11) NOT NULL,
  `terlapor` int(11) NOT NULL,
  PRIMARY KEY (`ID_finish`),
  KEY `pelapor` (`pelapor`),
  KEY `terlapor` (`terlapor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `finish`
--

INSERT INTO `finish` (`ID_finish`, `pelapor`, `terlapor`) VALUES
(4, 11, 24),
(5, 7, 25),
(6, 8, 26);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `ID_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_kategori`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`ID_kategori`, `jenis`) VALUES
(1, 'tas ransel'),
(2, 'baju kaca'),
(3, 'jam tangan'),
(4, 'sepatu kuda'),
(5, 'helm motor'),
(6, 'headset laptop'),
(7, 'notebooks'),
(8, 'laptop'),
(9, 'jam kaca'),
(10, 'cool pad'),
(11, 'kategori'),
(12, 'remote proyektor');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasi`
--

CREATE TABLE IF NOT EXISTS `lokasi` (
  `ID_lokasi` int(11) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `att` varchar(30) NOT NULL,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_lokasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `lokasi`
--

INSERT INTO `lokasi` (`ID_lokasi`, `lat`, `att`, `nama`) VALUES
(0, '-7.956071325935928', '112.61624937548049', 'Tempat Nongkrong Poltek'),
(1, '-7.952588553137637', '112.61437358993533', 'Bundaran UB'),
(2, '-7.9529004333752615', '112.6138858312654', 'Perpustakaan'),
(3, '-7.952711251305582', '112.612523265047', 'Kantin FIB'),
(4, '-7.955847613302229', '112.61569288649082', 'Rektorat UB'),
(5, '-7.952572174107272', '112.6144392405796', 'Griya Santa'),
(6, '-7.952748199951896', '112.61190519129752', 'Kantin PTIIK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan`
--

CREATE TABLE IF NOT EXISTS `pesan` (
  `ID_msg` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `isi` longtext NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`ID_msg`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data untuk tabel `pesan`
--

INSERT INTO `pesan` (`ID_msg`, `judul`, `nama`, `email`, `isi`, `waktu`) VALUES
(3, 'Subjectssssssssss', 'Namessssssss', 'Emailsssssssss', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam cursus. Morbi ut mi. Nullam enim leo, egestas id, condimentum at, laoreet mattis, massa. Sed eleifend nonummy diam. Praesent mauris ante, elementum et, bibendum at, posuere sit amet, nibh. Duis tincidunt lectus quis dui viverra vestibulum. Suspendisse vulputate aliquam dui. Nulla elementum dui ut augue. Aliquam vehicula mi at mauris. Maecenas placerat, nisl at consequat rhoncus, sem nunc gravida justo, quis eleifend arcu velit quis lacus. Morbi magna magna, tincidunt a, mattis non, imperdiet vitae, tellus. Sed odio est, auctor ac, sollicitudin in, consequat vitae, orci. Fusce id felis. Vivamus sollicitudin metus eget eros.\nPellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In posuere felis nec tortor. Pellentesque faucibus. Ut accumsan ultricies elit. Maecenas at justo id velit placerat molestie. Donec dictum lectus non odio. Cras a ante vitae enim iaculis aliquam. Mauris nunc quam, venenatis nec, euismod sit amet, egestas placerat, est. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras id elit. Integer quis urna. Ut ante enim, dapibus malesuada, fringilla eu, condimentum quis, tellus. Aenean porttitor eros vel dolor. Donec convallis pede venenatis nibh. Duis quam. Nam eget lacus. Aliquam erat volutpat. Quisque dignissim congue leo.', '2013-05-26 07:09:00'),
(4, 'Subjecttttttttt', 'Nametttttt', 'Emailtttttttttt', 'Nunc tempus felis vitae urna. Vivamus porttitor, neque at volutpat rutrum, purus nisi eleifend libero, a tempus libero lectus feugiat felis. Morbi diam mauris, viverra in, gravida eu, mattis in, ante. Morbi eget arcu. Morbi porta, libero id ullamcorper nonummy, nibh ligula pulvinar metus, eget consectetuer augue nisi quis lacus. Ut ac mi quis lacus mollis aliquam. Curabitur iaculis tempus eros. Curabitur vel mi sit amet magna malesuada ultrices. Ut nisi erat, fermentum vel, congue id, euismod in, elit. Fusce ultricies, orci ac feugiat suscipit, leo massa sodales velit, et scelerisque mi tortor at ipsum. Proin orci odio, commodo ac, gravida non, tristique vel, tellus. Pellentesque nibh libero, ultricies eu, sagittis non, mollis sed, justo. Praesent metus ipsum, pulvinar pulvinar, porta id, fringilla at, est.\nPhasellus felis dolor, scelerisque a, tempus eget, lobortis id, libero. Donec scelerisque leo ac risus. Praesent sit amet est. In dictum, dolor eu dictum porttitor, enim felis viverra mi, eget luctus massa purus quis odio. Etiam nulla massa, pharetra facilisis, volutpat in, imperdiet sit amet, sem. Aliquam nec erat at purus cursus interdum. Vestibulum ligula augue, bibendum accumsan, vestibulum ut, commodo a, mi. Morbi ornare gravida elit. Integer congue, augue et malesuada iaculis, ipsum dui aliquet felis, at cursus magna nisl nec elit. Donec iaculis diam a nisi accumsan viverra.', '2013-05-26 07:11:00'),
(15, 'Subjectdddddddddddddd', 'Nameuuuuuuu', 'Emailuuuuuuuuuuu', 'Messageuuuuu', '2013-06-02 06:16:00'),
(16, 'Subjectaaaaaaaaaaaaaaaaaaa', 'Namegggggggggggg', 'Emailggggggggg', 'Messageggggggggggggggggggggg', '2013-06-02 06:20:00'),
(27, 'Subject', 'Name', 'Email', 'Message', '2013-06-05 03:19:00'),
(32, 'Subject', 'Name', 'Email', 'Message', '2013-06-05 05:56:00'),
(47, 'Subjectdd', 'Name', 'Email@mail.com', 'Message', '2013-06-06 04:33:00'),
(48, 'coba', 'nbanbsasa', 'Email@nnn.com', 'Messagexxxxxxxxxxxx', '2013-06-06 11:24:00'),
(49, 'Subjectffffff', 'Namefffffffff', 'Email@fff.com', 'Message', '2013-06-06 11:27:00'),
(51, 'Subject', 'Name', 'Email@ggg.com', 'Message', '2013-06-06 11:28:00'),
(52, 'Subjectddddddddddddddddddddddd', 'Name', 'Email@ggg.com', 'Message', '2013-06-06 11:43:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `subjek`
--

CREATE TABLE IF NOT EXISTS `subjek` (
  `ID_subjek` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `no_ktp` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `RT` varchar(50) NOT NULL,
  `RW` varchar(50) NOT NULL,
  `kelurahan` varchar(50) NOT NULL,
  `kecamatan` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(2) NOT NULL,
  `pekerjaan` varchar(100) NOT NULL,
  `no_kontak` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`ID_subjek`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data untuk tabel `subjek`
--

INSERT INTO `subjek` (`ID_subjek`, `nama`, `no_ktp`, `alamat`, `RT`, `RW`, `kelurahan`, `kecamatan`, `jenis_kelamin`, `pekerjaan`, `no_kontak`, `status`) VALUES
(1, 'Lingga Perdana', '11111111111199999999', 'Jl Lorem Ipsum Color Sir Amet', '2', '3', 'Malang', 'Singosari', 'L', 'Programmer', '000088889999', 0),
(2, 'Nesiviya ', '333334444444444444444', 'Jl Malang Utara', '3', '4', 'Bojonegoro', 'Malang', 'P', 'Mahasiswa', '00008888666666666', 0),
(3, 'Aga Dont Cry', '111111111222222f', 'Jl Kenangan Bersamanya', '3', '5', 'Gresik', 'Solo', 'L', 'Mahasiswa', '2222222333333', 0),
(5, 'Coba teeeeeeeeeeeesssssss', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(6, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(7, 'lingga perdana 6', 'Nomor KTPd1111111111111111111', 'Alamat1111111111111', 'dd', 'R', 'Kelurahanddddd', 'Kecamatanccccccccc', 'L', 'Pekerjaandd', 'Nomor Telepondddd', 0),
(8, 'lingga perdana 6', 'Nomor KTPd1111111111111111111', 'ddddddd', 'dd', 'R', 'Kelurahanddddd', 'Kecamatanccccccccc', 'P', 'Pekerjaandd', 'Noccccccccccc', 0),
(9, 'Namahh', 'Nomor KTPhhh', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatanhhh', 'L', 'Pekerjaanhhh', 'Nomor Teleponhh', 0),
(10, 'Namahh', 'Nomor KTP', 'Alamat', 'RThh', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaanhhh', 'Nomor Teleponhhh', 0),
(11, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(12, 'Nama', 'Nomor KTP', '', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(13, 'Nama', '', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(14, 'Nama', 'Nomor KTP', 'Alamat', 'RT', '', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(15, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(16, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(17, 'testing', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(18, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(19, 'Lingga Perdana Kusuma', 'oooooooooooooor', 'oooooooooooooo', 'oooooooooooo', 'oooooooooooooooo', 'ooooooooooooo', 'ooooooooooooooo', 'L', 'ooooooooooooo', 'ooooooooooooooooooo', 0),
(20, 'Namabbbbbbbbbb', 'Nomor KTPbbbbbbbbbbb', 'Alamatbbbbbbbbbbbb', 'RTbbbbbbbbbb', 'RWbbbbbbbbb', 'Kelurahanbbbbbbbbb', 'Kecamatanbbbbbbbbb', 'L', 'Pekerjaanbbbbb', 'Nomor Teleponbbbbbbbbbbbb', 0),
(24, 'Namavvvvvvv', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 1),
(25, 'Neny', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'P', 'Pekerjaan', 'Nomor Teleponn88888888888', 1),
(26, 'Coba Terlapor', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 1),
(27, 'tessssss', 'ssssssssss', 'ssssssssssssssssss', 'ssssssssssssssss', 'ssssssssssss', 'ssssssssssssssss', 'sssssssssssssssss', 'L', 'ssssssssssss', 'sssssssssssssssssssss', 0),
(28, 'Namaccccccccsssssssssss', 'Nomor KTPcccccccccc', 'Alamatcccccc', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(29, 'Namavvvvvvvvvvvv', 'Nomor KTPvvvvvvvvvvvvvvvvvvv', 'Alamat', 'RTvvvvvvvvvvvvv', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(30, 'Namaeeeeeeeeeee', 'Nomor KTPeeeeeeeeeee', 'Alamateeeeeeeeeeee', 'RTeeeeeeeee', 'RW', 'Kelurahaneeeeeeeeeeeeee', 'Kecamatan', 'P', 'Pekerjaan', 'Nomor Teleponeeeeeeeeee', 0),
(31, 'Namayyyyyyyyy', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(32, 'Namaeeeeeeeeeeeeeeeeeeeeeeeeee', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'P', 'Pekerjaan', 'Nomor Telepon', 0),
(33, 'ccccccc', 'gggggggggggg', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0),
(34, 'Nama', 'Nomor KTP', 'Alamat', 'RT', 'RW', 'Kelurahan', 'Kecamatan', 'L', 'Pekerjaan', 'Nomor Telepon', 0);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`jenis`) REFERENCES `kategori` (`ID_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `detail`
--
ALTER TABLE `detail`
  ADD CONSTRAINT `detail_ibfk_1` FOREIGN KEY (`no_subjek`) REFERENCES `subjek` (`ID_subjek`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_ibfk_2` FOREIGN KEY (`no_barang`) REFERENCES `barang` (`ID_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_ibfk_3` FOREIGN KEY (`no_lokasi`) REFERENCES `lokasi` (`ID_lokasi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `finish`
--
ALTER TABLE `finish`
  ADD CONSTRAINT `finish_ibfk_2` FOREIGN KEY (`terlapor`) REFERENCES `subjek` (`ID_subjek`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `finish_ibfk_4` FOREIGN KEY (`pelapor`) REFERENCES `detail` (`ID_detail`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
